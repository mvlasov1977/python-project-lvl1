# file cli.py

import prompt

def welcome_user(greeting):
    name = prompt.string( greeting )
    return name
