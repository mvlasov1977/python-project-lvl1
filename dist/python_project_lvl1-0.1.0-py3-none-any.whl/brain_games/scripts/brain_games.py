#!/usr/bin/env python3

_WELCOME = 'Welcome to the Brain Games!'

# print welcome message :)
def welcome_print(txt):
     print(txt)

# define function main
def main():
    welcome_print(_WELCOME)

# detect use type 
if __name__ == '__main__':
     main()
