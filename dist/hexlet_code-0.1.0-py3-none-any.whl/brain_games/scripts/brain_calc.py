#!/usr/bin/env python3

from brain_games.games.calc_game import main as main_calc


# execute calc game

def main():
    main_calc()
    return None


# detect use type


if __name__ == '__main__':
    main()
