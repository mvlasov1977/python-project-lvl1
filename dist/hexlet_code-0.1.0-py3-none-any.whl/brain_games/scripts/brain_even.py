#!/usr/bin/env python3

from brain_games.games.even_game import main as mane_even


# execute even game


def main():
    mane_even()
    return None

# detect use type


if __name__ == '__main__':
    main()
